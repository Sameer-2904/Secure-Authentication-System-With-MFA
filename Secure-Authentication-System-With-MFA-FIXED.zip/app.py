from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_bcrypt import Bcrypt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from dotenv import load_dotenv
import jwt
import datetime
import pyotp
import sqlite3
import os
import io
import re
import base64
import secrets
import pyqrcode
from functools import wraps

load_dotenv()

app = Flask(__name__)

# SECRET_KEY must come from the environment in production. We generate a
# random one on the fly (with a warning) only so the app doesn't crash if
# the developer forgot to set it locally — this random key changes on every
# restart, which will invalidate old sessions/tokens, so it is NOT a
# substitute for setting FLASK_SECRET_KEY / JWT_SECRET_KEY for real use.
if not os.environ.get('FLASK_SECRET_KEY'):
    print("WARNING: FLASK_SECRET_KEY not set in environment. Using a random "
          "throwaway key for this run only. Set FLASK_SECRET_KEY (and "
          "JWT_SECRET_KEY) in a .env file before deploying.")

app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY') or secrets.token_hex(32)
# Keep the JWT signing key separate from the Flask session key so that
# rotating one doesn't silently invalidate the other.
JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or app.config['SECRET_KEY']

# --- HTTPS enforcement -------------------------------------------------
# The registration response carries the raw MFA secret (needed once, so the
# user can set up their authenticator app). If that request/response ever
# travels over plain HTTP, anyone on the network path can read the secret
# and clone the user's MFA — set FORCE_HTTPS=1 (in production, behind a real
# TLS-terminating proxy or with an SSL cert) to have every request redirected
# to HTTPS and to send a Strict-Transport-Security header.
FORCE_HTTPS = os.environ.get('FORCE_HTTPS', '0') == '1'
if FORCE_HTTPS:
    from flask_talisman import Talisman
    Talisman(app, force_https=True, strict_transport_security=True)
else:
    print("NOTE: FORCE_HTTPS is off. This is fine for local development, "
          "but in any real deployment set FORCE_HTTPS=1 and serve over TLS "
          "— otherwise MFA secrets and passwords can be sniffed in transit.")

app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(minutes=30)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
# Only mark the session cookie "Secure" (HTTPS-only) when we're actually
# enforcing HTTPS — otherwise the cookie would silently stop working on
# plain-HTTP local development.
app.config['SESSION_COOKIE_SECURE'] = FORCE_HTTPS

EMAIL_REGEX = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
SPECIAL_CHAR_REGEX = re.compile(r'[!@#$%^&*()_+\-=\[\]{};\':"\\|,.<>\/?~`]')

# A short list of extremely common passwords that technically pass the
# character-class rules below but offer no real security (e.g.
# "Password1!" satisfies every rule but is one of the first guesses any
# attacker tries).
COMMON_WEAK_PASSWORDS = {
    'password1!', 'password123!', 'welcome1!', 'qwerty123!', 'admin123!',
    'iloveyou1!', 'password@123', 'p@ssw0rd', 'p@ssword1',
}

def validate_password_strength(password):
    """
    Standard-strength password policy:
      - at least 8 characters
      - at least one uppercase letter
      - at least one lowercase letter
      - at least one digit
      - at least one special character
      - not one of a handful of common/weak passwords

    Returns a list of human-readable problems; an empty list means the
    password passes.
    """
    problems = []

    if len(password) < 8:
        problems.append("be at least 8 characters long")
    if not re.search(r'[A-Z]', password):
        problems.append("include at least one uppercase letter (A-Z)")
    if not re.search(r'[a-z]', password):
        problems.append("include at least one lowercase letter (a-z)")
    if not re.search(r'\d', password):
        problems.append("include at least one number (0-9)")
    if not SPECIAL_CHAR_REGEX.search(password):
        problems.append("include at least one special character (e.g. ! @ # $ % ^ & *)")
    if password.lower() in COMMON_WEAK_PASSWORDS:
        problems.append("not be a commonly used password")

    return problems

bcrypt = Bcrypt(app)
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Database initialization
DATABASE = 'users.db'

def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """
    Initialize database with users table, and self-heal the schema for
    databases created by an older version of this app (adds any missing
    columns instead of requiring the user to delete users.db).
    """
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            mfa_secret TEXT NOT NULL,
            mfa_confirmed BOOLEAN DEFAULT 0,
            failed_attempts INTEGER DEFAULT 0,
            locked BOOLEAN DEFAULT 0,
            locked_until TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()

    # Migration: older databases (created before MFA-setup-confirmation was
    # added) won't have this column yet — add it instead of crashing.
    cursor.execute("PRAGMA table_info(users)")
    existing_columns = {row[1] for row in cursor.fetchall()}
    if 'mfa_confirmed' not in existing_columns:
        cursor.execute("ALTER TABLE users ADD COLUMN mfa_confirmed BOOLEAN DEFAULT 0")
        conn.commit()
        print("Migrated existing database: added mfa_confirmed column.")

    conn.close()
    print("Database ready.")

def unlock_if_expired(user, conn, cursor):
    """
    If the account is locked but the lock window has passed, clear the lock
    and reset failed attempts. Returns True if the account is (now) usable,
    False if it's still locked.

    BUG FIX: previously 'locked_until' was written on lockout but never
    checked anywhere, so an account stayed locked forever instead of just
    for 30 minutes.
    """
    if not user['locked']:
        return True

    if user['locked_until'] is None:
        return False

    # Compare the stored lock expiry against SQLite's own clock so we don't
    # need to worry about timezone mismatches between Python and the DB.
    cursor.execute("SELECT (locked_until > datetime('now')) AS still_locked FROM users WHERE id = ?",
                    (user['id'],))
    row = cursor.fetchone()
    still_locked = bool(row['still_locked']) if row else False

    if still_locked:
        return False

    cursor.execute('''
        UPDATE users SET locked = 0, locked_until = NULL, failed_attempts = 0
        WHERE id = ?
    ''', (user['id'],))
    conn.commit()
    return True

def token_required(f):
    """Decorator to check if valid JWT token is present"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return jsonify({"message": "Token is missing"}), 401

        parts = auth_header.split(" ")
        if len(parts) != 2 or parts[0] != 'Bearer':
            return jsonify({"message": "Token is invalid"}), 401
        token = parts[1]

        try:
            data = jwt.decode(token, JWT_SECRET_KEY, algorithms=['HS256'])
            current_user = data['user']
        except jwt.ExpiredSignatureError:
            return jsonify({"message": "Token has expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"message": "Token is invalid"}), 401

        return f(current_user, *args, **kwargs)

    return decorated_function

@app.route('/')
def home():
    """Home page - redirect to login"""
    return render_template('login.html')

@app.route('/register', methods=['GET'])
def register_page():
    """Display registration page"""
    return render_template('register.html')

@app.route('/otp')
def otp_page():
    """
    Display the OTP verification page.

    BUG FIX: this route didn't exist at all before. login.html redirects the
    browser here with window.location.href = '/otp' after a successful
    password check, so without this route the whole login flow 404'd right
    after entering the correct password.
    """
    if not session.get('username'):
        # No password-verified session -> send them back to login instead
        # of showing an OTP form with nothing to verify against.
        return redirect(url_for('home'))
    return render_template('otp.html')

@app.route('/complete-setup')
def complete_setup_page():
    """
    Page for confirming MFA setup with a live OTP code. Used both right
    after registration and if a user closes the tab before confirming and
    tries to log in again later (login() will point them back here).
    """
    return render_template('complete_setup.html')

@app.route('/dashboard')
def dashboard():
    """Dashboard after successful login"""
    return render_template('dashboard.html')

@app.route('/api/register', methods=['POST'])
@limiter.limit("5 per hour")
def register():
    """Register a new user"""
    try:
        data = request.json
        username = data.get('username', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '')
        
        # Validation
        if not username or not email or not password:
            return jsonify({"message": "All fields are required"}), 400

        if len(username) < 3:
            return jsonify({"message": "Username must be at least 3 characters"}), 400

        # BUG FIX: email format was never validated, so "notanemail" would
        # be accepted and later break the MFA provisioning URI / any actual
        # email use.
        if not EMAIL_REGEX.match(email):
            return jsonify({"message": "Please enter a valid email address"}), 400

        # Standard password complexity: length + uppercase + lowercase +
        # digit + special character, and reject a few known weak passwords.
        password_problems = validate_password_strength(password)
        if password_problems:
            return jsonify({
                "message": "Password must " + ", ".join(password_problems)
            }), 400

        conn = get_db()
        try:
            cursor = conn.cursor()
            # Check if user already exists
            cursor.execute('SELECT * FROM users WHERE username = ? OR email = ?', (username, email))
            if cursor.fetchone():
                return jsonify({"message": "Username or email already exists"}), 400

            # Create user
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
            mfa_secret = pyotp.random_base32()

            cursor.execute('''
                INSERT INTO users (username, email, password_hash, mfa_secret)
                VALUES (?, ?, ?, ?)
            ''', (username, email, hashed_password, mfa_secret))
            conn.commit()
        finally:
            conn.close()

        # Generate QR code
        totp = pyotp.TOTP(mfa_secret)
        qr = pyqrcode.create(totp.provisioning_uri(
            name=email,
            issuer_name='Secure Auth System'
        ))

        # Convert QR code to base64
        qr_buffer = io.BytesIO()
        qr.svg(qr_buffer, scale=8)
        qr_buffer.seek(0)
        qr_base64 = base64.b64encode(qr_buffer.getvalue()).decode('utf-8')

        return jsonify({
            "message": "User registered. Scan the QR code, then enter the 6-digit code it shows to activate MFA.",
            "mfa_secret": mfa_secret,
            "qr_code": qr_base64
        }), 201

    except sqlite3.IntegrityError:
        # Race condition: two requests could pass the "already exists" check
        # at the same time; the UNIQUE constraint is the real backstop.
        return jsonify({"message": "Username or email already exists"}), 400
    except Exception as e:
        app.logger.exception("Registration error")
        return jsonify({"message": "Registration failed. Please try again."}), 500

@app.route('/api/confirm-mfa-setup', methods=['POST'])
@limiter.limit("10 per minute")
def confirm_mfa_setup():
    """
    Confirm that the user actually scanned the QR code into a working
    authenticator app, by requiring one live OTP code before the account
    is usable. This is a usability/setup-integrity check, not a defense
    against someone else having copied the secret in transit — anyone who
    saw the same QR/secret could also produce a valid code here. HTTPS in
    transit and treating the QR/secret as a one-time secret (see the
    warning shown on the registration page) are what actually protect
    against that.
    """
    try:
        data = request.json
        username = data.get('username', '').strip()
        otp = data.get('otp', '').strip()

        if not username or not otp:
            return jsonify({"message": "Username and OTP are required"}), 400

        if not otp.isdigit() or len(otp) != 6:
            return jsonify({"message": "OTP must be 6 digits"}), 400

        conn = get_db()
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
            user = cursor.fetchone()

            if not user:
                return jsonify({"message": "Invalid username or OTP"}), 401

            if user['mfa_confirmed']:
                return jsonify({"message": "MFA setup is already confirmed for this account."}), 400

            totp = pyotp.TOTP(user['mfa_secret'])
            if not totp.verify(otp, valid_window=1):
                return jsonify({"message": "Invalid OTP"}), 401

            cursor.execute('UPDATE users SET mfa_confirmed = 1 WHERE id = ?', (user['id'],))
            conn.commit()
        finally:
            conn.close()

        return jsonify({"message": "MFA setup confirmed! You can now log in."}), 200

    except Exception as e:
        app.logger.exception("MFA setup confirmation error")
        return jsonify({"message": "Could not confirm MFA setup. Please try again."}), 500

@app.route('/api/resend-mfa-setup', methods=['POST'])
@limiter.limit("5 per hour")
def resend_mfa_setup():
    """
    Regenerate the QR code for an account that was registered but never had
    its MFA setup confirmed (e.g. the user closed the tab). Requires the
    password again, same as a normal login, so this can't be used to fish
    for someone else's secret just by guessing a username.
    """
    try:
        data = request.json
        username = data.get('username', '').strip()
        password = data.get('password', '')

        if not username or not password:
            return jsonify({"message": "Username and password are required"}), 400

        conn = get_db()
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
            user = cursor.fetchone()

            # Same generic message regardless of which check fails, so this
            # endpoint doesn't become a way to enumerate usernames either.
            if not user or not bcrypt.check_password_hash(user['password_hash'], password):
                return jsonify({"message": "Invalid username or password"}), 401

            if user['mfa_confirmed']:
                return jsonify({"message": "MFA setup is already confirmed for this account. Please log in."}), 400

            mfa_secret = user['mfa_secret']
            email = user['email']
        finally:
            conn.close()

        totp = pyotp.TOTP(mfa_secret)
        qr = pyqrcode.create(totp.provisioning_uri(name=email, issuer_name='Secure Auth System'))
        qr_buffer = io.BytesIO()
        qr.svg(qr_buffer, scale=8)
        qr_buffer.seek(0)
        qr_base64 = base64.b64encode(qr_buffer.getvalue()).decode('utf-8')

        return jsonify({
            "message": "Scan the QR code, then enter the 6-digit code it shows to activate MFA.",
            "mfa_secret": mfa_secret,
            "qr_code": qr_base64
        }), 200

    except Exception as e:
        app.logger.exception("Resend MFA setup error")
        return jsonify({"message": "Could not regenerate setup QR code. Please try again."}), 500

@app.route('/api/login', methods=['POST'])
@limiter.limit("10 per minute")
def login():
    """Authenticate user with username and password"""
    try:
        data = request.json
        username = data.get('username', '').strip()
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({"message": "Username and password are required"}), 400

        conn = get_db()
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
            user = cursor.fetchone()

            # Use a generic message for "no such user" so we don't reveal
            # whether a username exists (basic user-enumeration hardening).
            if not user:
                bcrypt.generate_password_hash(password)  # constant-time-ish decoy hash
                return jsonify({"message": "Invalid credentials"}), 401

            # BUG FIX: previously 'locked' was checked but never un-set, so
            # once an account hit 5 failed attempts it stayed locked
            # forever instead of for the intended 30 minutes.
            if not unlock_if_expired(user, conn, cursor):
                return jsonify({"message": "Account is locked. Try again later."}), 403
            if user['locked']:
                # unlock_if_expired committed a fresh unlock; re-read the row
                cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
                user = cursor.fetchone()

            # Verify password
            if not bcrypt.check_password_hash(user['password_hash'], password):
                failed_attempts = user['failed_attempts'] + 1

                if failed_attempts >= 5:
                    cursor.execute('''
                        UPDATE users
                        SET failed_attempts = ?, locked = 1, locked_until = datetime('now', '+30 minutes')
                        WHERE id = ?
                    ''', (failed_attempts, user['id']))
                    conn.commit()
                    return jsonify({"message": "Account locked due to multiple failed attempts. Try again in 30 minutes."}), 403
                else:
                    cursor.execute('''
                        UPDATE users SET failed_attempts = ? WHERE id = ?
                    ''', (failed_attempts, user['id']))
                    conn.commit()
                    return jsonify({"message": f"Invalid credentials. {5 - failed_attempts} attempts remaining"}), 401

            # Reset failed attempts on successful password check
            cursor.execute('UPDATE users SET failed_attempts = 0 WHERE id = ?', (user['id'],))
            conn.commit()

            # This account was registered but the user never confirmed a
            # working OTP code (e.g. they closed the tab before finishing
            # setup on the registration page). Don't let a half-set-up
            # account log in — send them back to finish activating MFA
            # instead of silently skipping the check.
            if not user['mfa_confirmed']:
                return jsonify({
                    "message": "MFA setup was never confirmed for this account. Please finish activating it.",
                    "mfa_setup_required": True,
                    "username": username
                }), 403
        finally:
            conn.close()

        # Regenerate the session on privilege change to reduce session
        # fixation risk, then store user info for the OTP step.
        session.clear()
        session.permanent = True
        session['username'] = username
        session['user_id'] = user['id']

        return jsonify({"message": "Password verified. Enter OTP."}), 200

    except Exception as e:
        app.logger.exception("Login error")
        return jsonify({"message": "Login failed. Please try again."}), 500

@app.route('/api/verify-otp', methods=['POST'])
@limiter.limit("10 per minute")
def verify_otp():
    """Verify OTP from TOTP app"""
    try:
        data = request.json
        otp = data.get('otp', '').strip()
        
        if not session.get('username'):
            return jsonify({"message": "Please login first"}), 401
        
        if not otp or not otp.isdigit() or len(otp) != 6:
            return jsonify({"message": "OTP must be 6 digits"}), 400

        conn = get_db()
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE username = ?', (session['username'],))
            user = cursor.fetchone()

            if not user:
                session.clear()
                return jsonify({"message": "Session expired. Please login again."}), 401

            # Verify OTP (valid_window=1 tolerates minor clock drift between
            # the server and the user's authenticator app by also accepting
            # the previous/next 30-second code).
            totp = pyotp.TOTP(user['mfa_secret'])
            if not totp.verify(otp, valid_window=1):
                return jsonify({"message": "Invalid OTP"}), 401

            # Generate JWT token, signed with the dedicated JWT key.
            token = jwt.encode({
                'user': user['username'],
                'user_id': user['id'],
                'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
            }, JWT_SECRET_KEY, algorithm='HS256')
        finally:
            conn.close()

        # Clear session after successful login
        session.clear()

        return jsonify({
            "message": "Login successful",
            "token": token,
            "username": user['username']
        }), 200

    except Exception as e:
        app.logger.exception("OTP verification error")
        return jsonify({"message": "OTP verification failed. Please try again."}), 500

@app.route('/api/profile', methods=['GET'])
@token_required
def profile(current_user):
    """Get user profile (requires valid token)"""
    try:
        conn = get_db()
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT id, username, email, created_at FROM users WHERE username = ?', (current_user,))
            user = cursor.fetchone()
        finally:
            conn.close()

        if not user:
            return jsonify({"message": "User not found"}), 404

        return jsonify({
            "username": user['username'],
            "email": user['email'],
            "created_at": user['created_at']
        }), 200

    except Exception as e:
        app.logger.exception("Profile fetch error")
        return jsonify({"message": "Could not load profile."}), 500

@app.route('/api/logout', methods=['POST'])
def logout():
    """Logout user"""
    session.clear()
    return jsonify({"message": "Logged out successfully"}), 200

if __name__ == '__main__':
    init_db()
    # BUG FIX: debug mode was hardcoded to True. Flask's debugger allows
    # arbitrary code execution if it's ever exposed (e.g. deployed as-is),
    # so it must be opt-in via an environment variable, off by default.
    debug_mode = os.environ.get('FLASK_DEBUG', '0') == '1'
    app.run(debug=debug_mode, host='127.0.0.1', port=5000)
